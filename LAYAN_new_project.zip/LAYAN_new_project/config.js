/*
  إعدادات مشروع LAYAN الجديد.
  لا تضع مفاتيح سرية أو service_role key داخل ملفات الواجهة.
  أضف بيانات مشروع Supabase العامة بعد التأكد من سياسات RLS.
*/
window.LAYAN_CONFIG = {
  supabaseUrl: "",
  supabaseAnonKey: "",
  offersTable: "property_offers",
  storageBucket: "layan_real_estat",
  governorate: "أسيوط"
};
