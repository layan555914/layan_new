const sampleOffers = [
  {title:"شقة سكنية بمشروع سكني مميز",property_type:"شقة",area:"أسيوط الجديدة",total_price:1600000,down_payment:300000,paid_amount:250000,remaining_installments:850000,transfer_fee:100000,discount_percent:0,description:"مثال توضيحي لعرض عقاري. تحقق من البيانات والمستندات قبل التعامل."},
  {title:"فيلا مستقلة داخل كمبوند",property_type:"فيلا",area:"أسيوط",total_price:4200000,down_payment:800000,paid_amount:630000,remaining_installments:2200000,transfer_fee:200000,discount_percent:3,description:"مثال توضيحي فقط، وليس عرضًا حقيقيًا."},
  {title:"محل تجاري بموقع حيوي",property_type:"محل",area:"أسيوط",total_price:950000,down_payment:200000,paid_amount:150000,remaining_installments:400000,transfer_fee:80000,discount_percent:5,description:"مثال توضيحي فقط، وتختلف شروط التنازل حسب المطور."},
  {title:"أرض سكنية مميزة",property_type:"أرض",area:"أسيوط الجديدة",total_price:800000,down_payment:150000,paid_amount:100000,remaining_installments:350000,transfer_fee:50000,discount_percent:2,description:"مثال توضيحي فقط، راجع الملكية والتخصيص وشروط الجهة."},
  {title:"شقة واسعة مناسبة للعائلة",property_type:"شقة",area:"منفلوط",total_price:1100000,down_payment:220000,paid_amount:180000,remaining_installments:570000,transfer_fee:70000,discount_percent:0,description:"مثال توضيحي فقط."},
  {title:"وحدة تجارية في منطقة نشطة",property_type:"محل",area:"القوصية",total_price:700000,down_payment:140000,paid_amount:100000,remaining_installments:360000,transfer_fee:60000,discount_percent:1,description:"مثال توضيحي فقط."}
];
const $ = (s) => document.querySelector(s);
const grid = $("#offersGrid");
let selectedKind = "";
let offers = [...sampleOffers];
const money = n => new Intl.NumberFormat("ar-EG",{maximumFractionDigits:0}).format(Number(n)||0) + " ج.م";

function card(o) {
  const image = o.image_url ? `style="background-image:linear-gradient(0deg,#071b30a8,transparent),url('${o.image_url}');background-size:cover;background-position:center"` : "";
  return `<article class="offer-card">
    <div class="offer-image" ${image}><span class="type-tag">${escapeHtml(o.property_type||"عقار")}</span><span class="location-tag">⌖ ${escapeHtml(o.area||"أسيوط")}</span></div>
    <div class="offer-body"><h3>${escapeHtml(o.title||"عرض عقاري")}</h3><div class="offer-location">محافظة ${escapeHtml(o.governorate||"أسيوط")} · تفاصيل التنازل موضحة أدناه</div>
    <div class="metrics"><div class="metric"><span>المقدم المطلوب</span><strong>${money(o.down_payment)}</strong></div><div class="metric"><span>المبلغ المدفوع</span><strong>${money(o.paid_amount)}</strong></div><div class="metric"><span>الأقساط المتبقية</span><strong>${money(o.remaining_installments)}</strong></div></div>
    <div class="fees"><div class="fee">رسوم التنازل<strong>${money(o.transfer_fee)}</strong></div><div class="fee">نسبة الخصم<strong>${Number(o.discount_percent)||0}%</strong></div></div>
    <div class="card-actions"><button class="btn btn-dark details-btn" data-title="${escapeAttr(o.title||"عرض عقاري")}" data-desc="${escapeAttr(o.description||"لا يوجد وصف.")}">عرض التفاصيل</button><button class="btn btn-gold contact-btn">طلب تواصل</button></div></div></article>`;
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function escapeAttr(s){return escapeHtml(s).replace(/`/g,"&#96;");}
function render(){
 const q=$("#searchInput").value.trim().toLowerCase(), type=$("#typeFilter").value, area=$("#areaFilter").value;
 const filtered=offers.filter(o=>(!selectedKind||o.property_type===selectedKind)&&(!type||o.property_type===type)&&(!area||String(o.area||"").includes(area))&&(!q||`${o.title} ${o.area} ${o.description||""}`.toLowerCase().includes(q)));
 grid.innerHTML=filtered.map(card).join("");
 $("#statusMessage").textContent = filtered.length ? `عدد العروض المعروضة: ${filtered.length}. البيانات الحالية أمثلة توضيحية ما لم يتم ربط قاعدة البيانات.` : "لا توجد عروض مطابقة لخيارات البحث.";
 document.querySelectorAll(".details-btn").forEach(b=>b.addEventListener("click",()=>alert(`${b.dataset.title}\n\n${b.dataset.desc}\n\nتأكد من مستندات الوحدة وموافقة المطور قبل دفع أي مبالغ.`)));
 document.querySelectorAll(".contact-btn").forEach(b=>b.addEventListener("click",()=>alert("ميزة طلب التواصل تحتاج ربط حسابات المستخدمين وقناة تواصل آمنة.")));
}
$("#searchBtn").addEventListener("click",render);
$("#searchInput").addEventListener("input",render);
$("#typeFilter").addEventListener("change",render);
$("#areaFilter").addEventListener("change",render);
$("#categoryRow").addEventListener("click",e=>{const b=e.target.closest("[data-kind]");if(!b)return;selectedKind=b.dataset.kind;document.querySelectorAll(".category").forEach(x=>x.classList.toggle("active",x===b));render();});
const dialog=$("#offerDialog");
function openDialog(){dialog.showModal();}
$("#addOfferBtn").addEventListener("click",openDialog);$("#addOfferTop").addEventListener("click",openDialog);$("#closeDialog").addEventListener("click",()=>dialog.close());
$("#loginBtn").addEventListener("click",()=>alert("تسجيل الدخول يحتاج إعداد نظام مصادقة آمن."));
$("#offerForm").addEventListener("submit",e=>{
 e.preventDefault(); const f=new FormData(e.currentTarget), photos=$("#photosInput").files;
 const o=Object.fromEntries(f.entries()); ["total_price","down_payment","paid_amount","remaining_installments","transfer_fee","discount_percent"].forEach(k=>o[k]=Number(o[k]||0));
 o.governorate="أسيوط"; o.description=o.description||"لم يضف صاحب العرض وصفًا.";
 if(photos.length) alert("تم اختيار الصور للمعاينة، لكن لم تُرفع إلى الإنترنت. يلزم إعداد Supabase Storage.");
 offers.unshift(o);render();dialog.close();e.currentTarget.reset();$("#offers").scrollIntoView({behavior:"smooth"});
});
render();
