/* طبقة ربط أولية بـ Supabase.
   ضع رابط المشروع ومفتاح anon العام في config.js بعد إعداد سياسات الوصول.
   هذا الملف لا يحمل مكتبة Supabase تلقائيًا ولا يدّعي أن البيانات متصلة الآن. */
window.LAYAN_DB = {
  isConfigured() {
    const c = window.LAYAN_CONFIG || {};
    return Boolean(c.supabaseUrl && c.supabaseAnonKey);
  },
  async getOffers() {
    if (!this.isConfigured()) return null;
    // TODO: أضف Supabase JS client ثم نفّذ select آمنًا من جدول property_offers.
    throw new Error("لم يتم تفعيل عميل Supabase بعد. راجع README.md.");
  },
  async uploadImages(files) {
    if (!this.isConfigured()) throw new Error("أضف إعدادات Supabase أولًا.");
    // TODO: ارفع الصور إلى bucket مع سياسات تخزين آمنة.
    throw new Error("رفع الصور يحتاج إعداد عميل Supabase وسياسات Storage.");
  }
};
