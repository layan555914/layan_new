# خطوات النشر
1. فك ضغط الحزمة.
2. افتح مستودع `layan_real_esteat` في GitHub.
3. احتفظ بنسخة من `index.html` الحالي.
4. Add file → Upload files، ثم ارفع `index.html` و`styles.css` و`app.js` إلى الجذر.
5. اكتب رسالة commit مثل `Add LAYAN prototype` واضغط Commit changes.
6. Settings → Pages، اختر Deploy from a branch، الفرع `main` والمجلد `/(root)`.
7. انتظر النشر وافتح رابط Pages.
ملاحظة: هذه الخطوات تنشر الواجهة فقط، وليست قاعدة بيانات أو رفع صور حقيقيًا.
