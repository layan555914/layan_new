-- LAYAN: مخطط أولي لقاعدة بيانات Supabase
create extension if not exists pgcrypto;
create table if not exists public.property_offers (
 id uuid primary key default gen_random_uuid(), title text not null,
 governorate text not null default 'أسيوط', area text not null, property_type text not null,
 developer_name text, description text, total_price numeric(14,2) not null default 0 check(total_price>=0),
 paid_amount numeric(14,2) not null default 0 check(paid_amount>=0),
 required_down_payment numeric(14,2) not null default 0 check(required_down_payment>=0),
 remaining_installments numeric(14,2) not null default 0 check(remaining_installments>=0),
 transfer_fee_amount numeric(14,2) not null default 0 check(transfer_fee_amount>=0),
 transfer_fee_percent numeric(5,2) not null default 0 check(transfer_fee_percent>=0),
 paid_amount_discount numeric(14,2) not null default 0 check(paid_amount_discount>=0),
 contact_phone text, status text not null default 'pending' check(status in ('pending','published','rejected','closed')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.property_images (
 id uuid primary key default gen_random_uuid(), offer_id uuid not null references public.property_offers(id) on delete cascade,
 storage_path text not null, sort_order int not null default 0, created_at timestamptz not null default now()
);
create index if not exists property_offers_area_idx on public.property_offers(area);
create index if not exists property_offers_status_created_idx on public.property_offers(status,created_at desc);
alter table public.property_offers enable row level security;
alter table public.property_images enable row level security;
create policy "Public can view published offers" on public.property_offers for select using(status='published');
create policy "Public can view images of published offers" on public.property_images for select using(exists(select 1 from public.property_offers o where o.id=offer_id and o.status='published'));
-- لا تفتح الإدراج العام قبل إعداد تسجيل دخول/تحقق ومراجعة السياسات.
